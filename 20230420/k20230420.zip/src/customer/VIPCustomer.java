package customer;

public class VIPCustomer extends Customer {
	private int agentID;	// 담당 상담원 ID
	private double salesRatio;	// 추가 할인 비율
	
	public VIPCustomer() {
		setCustomerGrade("VIP");
		setBonusRatio(0.05);
		salesRatio = 0.1;
	}

	public int calcSales(int price) {
		return (int) (price * (1-salesRatio));
	}

	@Override
	public int calcBonus(int price) {
		return super.calcBonus(calcSales(price));
	}
	
}
