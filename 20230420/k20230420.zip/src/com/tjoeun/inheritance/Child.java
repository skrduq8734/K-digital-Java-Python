package com.tjoeun.inheritance;
		
public class Child extends Parent {
	private int age;
	private String nickname;
	
	public Child() {
		System.out.println("자식클래스의 생성자 실행");
	}
	/*
	public Child(String name, boolean gender, int age, String nickname) {
		super(name, gender);
		this.age = age;
		this.nickname = nickname;
	}
	*/
	public Child(String name, boolean gender, int age, String nickname) {
		this.age = age;
		this.nickname = nickname;
	}
	
	@Override
	public String toString() {
//		return "Child [age=" + age + ", nickname=" + nickname + ", getName()=" + getName() + ", isGender()="
//				+ isGender() + "]";
		return super.toString() + ", " + age + ", " + nickname;
	}	
}
