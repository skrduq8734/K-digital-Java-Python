package com.tjoeun.inheritance;

public class Parent {
	private String name;
	private boolean gender;
	
	// 부모클래스에서 기본생성자 미생성시 자식클래스에서 super()를 호출할때 오류발생
	public Parent() {
//		name = "무명씨";
//		gender = false;
		this("무명씨", false);
		System.out.println("부모클래스의 생성자 실행");
	}

	public Parent(String name, boolean gender) {
		super();
		this.name = name;
		this.gender = gender;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isGender() {
		return gender;
	}
	public void setGender(boolean gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return name + "(" + (gender?"남":"여") + ")";
	}
}
