package com.tjoeun.inheritance;

import java.util.Calendar;

// 파일 1개에 클래스 2개를 만들면 .java는 1개 .class는 각각 독립적으로 생성
// .java 파일의 이름과 같은 이름의 클래스만 public 사용 가능
class Date{
	private int year;
	private int month;
	private int day;
	
	public Date() {
		java.util.Date date = new java.util.Date();
		year = date.getYear() + 1900;
		month = date.getMonth() + 1;
		day = date.getDate();
		
		/*
		Calendar calendar = Calendar.getInstance();
		year = calendar.get(calendar.YEAR);
		month = calendar.get(calendar.MONTH);
		day = calendar.get(calendar.DATE);
		*/
	}
	

	public Date(int year, int month, int day) {
		super();
		this.year = year;
		this.month = month;
		this.day = day;
	}
	

	public int getYear() {
		return year;
	}


	public void setYear(int year) {
		this.year = year;
	}


	public int getMonth() {
		return month;
	}


	public void setMonth(int month) {
		this.month = month;
	}


	public int getDay() {
		return day;
	}


	public void setDay(int day) {
		this.day = day;
	}


	@Override
	public String toString() {
		return String.format("%4d년 %02d월 %02d일", year, month, day);
	}
	
}
class Time{
	private int hour;
	private int minute;
	private int second;
	public Time() {
		java.util.Date date = new java.util.Date();
		hour = date.getHours();
		minute = date.getMinutes();
		second = date.getSeconds();
	}
	
	public Time(int hour, int minute, int second) {
		super();
		this.hour = hour;
		this.minute = minute;
		this.second = second;
	}
	

	public int getHour() {
		return hour;
	}

	public void setHour(int hour) {
		this.hour = hour;
	}

	public int getMinute() {
		return minute;
	}

	public void setMinute(int minute) {
		this.minute = minute;
	}

	public int getSecond() {
		return second;
	}

	public void setSecond(int second) {
		this.second = second;
	}

	@Override
	public String toString() {
		
		return String.format("%02d시 %02d분 %02d초", hour, minute, second);
	}
}
class Now {
	// 클래스 포함: 클래스의 필드로 다른 클래스 객체를 선언해서 사용
	private Date date;
	private Time time;
	public Now() {
		date = new Date();
		time = new Time();
	}
	
	
	public Now(Date date, Time time) {
		super();
		this.date = date;
		this.time = time;
	}

	public Now(int year, int month, int day, int hour, int minute, int second) {
		super();
		date = new Date(year, month, day);
		time = new Time(hour, minute, second);
		
	}

	@Override
	public String toString() {
		return "Now [date=" + date + ", time=" + time + "]";
	}	
}
// 다중상속 못하니까 인터페이스 이용
public class ClassIncludeTest {
	public static void main(String[] args) {
		Date date = new Date();
		Date date2 = new Date(2023, 4, 25);
		System.out.println(date);
		System.out.println(date2);
		Time time = new Time();
		Time time2 = new Time(13, 34, 51);
		System.out.println(time);
		System.out.println(time2);
		
		System.out.println("=======================");
		Now now = new Now();
		System.out.println(now);	
		Now now2 = new Now(date2, time2);
		System.out.println(now2);	
		Now now3 = new Now(2023, 4, 25, 13, 34, 51);
		System.out.println(now3);	
		
	}
}
