package com.tjoeun.memoList;

import java.util.Scanner;
import java.util.StringTokenizer;

import javax.annotation.processing.AbstractProcessor;

public class MomeMain {
	static MemoList memoList = new MemoList();
	public static void main(String[] args) {
		boolean p = true;
		while(p) {
			System.out.print("\033[H\033[2J");
			Scanner scan = new Scanner(System.in);
			System.out.println("=========================================");
			System.out.println("1.입력 2.목록보기 3.수정 4.삭제 5.파일로 저장 6.파일에서 읽기 7.종료");
			System.out.println("=========================================");
			System.out.print("원하는 메뉴를 입력하세요: ");
			int menu = scan.nextInt();
			switch (menu) {
			case 1:
				insert();
				break;
			case 2:
				show();
				break;
			case 3:
				update();
				break;
			case 4:
				delete();
				break;
			case 5:
				fileWrite();
				break;
			case 6:
				fileRead();
				break;
			case 7:
				System.out.println("프로그램을 종료합니다!!!");
				p = false;
				break;
			default:
				System.out.println("메뉴는 1 ~ 7 사이로 입력해야 합니다.");
				
			}
		}

	}
	
	private static void fileRead() {
		Scanner scanner = new Scanner(System.in);
		System.out.print("읽어올 텍스트 파일 이름을 입력하세요: ");
		String filename = scanner.nextLine().trim();
		
		memoList.readMemo(filename);
	}

	private static void fileWrite() {
		Scanner scanner = new Scanner(System.in);
		System.out.print("저장할 텍스트 파일 이름을 입력하세요: ");
		String filename = scanner.nextLine().trim();

		memoList.writeMemo(filename);
		
	}

	private static void delete() {
		Scanner scan = new Scanner(System.in);
		System.out.print("삭제할 글의 번호를 입력하세요: ");
		int idx = scan.nextInt();
		scan.nextLine();
		MemoVO original = memoList.selectMemo(idx);
		if (original==null) {
			System.out.println(idx+"해당번호의 글이 존재하지 않습니다!!!");
		}
		else {
			System.out.println("삭제할 글 확인");
			System.out.println(original);
			System.out.print("패스워드를 입력하세요: ");
			String password = scan.nextLine().trim();
			if (password.equals(original.getPassword())) {
				memoList.deleteMemo(idx);
				System.out.println(idx+"번 글이 삭제되었습니다!!!");
			}else {
				System.out.println("비밀번호가 일치하지 않습니다!!!");
			}
		}
	}
	private static void update() {
		Scanner scan = new Scanner(System.in);
		System.out.print("수정할 글의 번호를 입력하세요: ");
		int idx = scan.nextInt();
		scan.nextLine();
		MemoVO original = memoList.selectMemo(idx);
		if (original==null) {
			System.out.println(idx+"해당번호의 글이 존재하지 않습니다!!!");
		}
		else {
			System.out.println("수정할 글 확인");
			System.out.println(original);
			System.out.print("패스워드를 입력하세요: ");
			String password = scan.nextLine().trim();
			if (password.equals(original.getPassword())) {
				System.out.print("수정할 메모를 입력하세요: ");
				String memo = scan.nextLine();
				memoList.updateMemo(idx, memo);
				System.out.println("수정되었습니다!!!");
			}else {
				System.out.println("비밀번호가 일치하지 않습니다!!!");
			}
		}
	}

	private static void del() {
		if (memoList.getMemoList().isEmpty()) {
			System.out.println("목록이 비어있습니다!!!");
		}else {
			Scanner scan = new Scanner(System.in);
			System.out.print("삭제할 글의 번호를 입력하세요: ");
			int num = scan.nextInt();
			scan.nextLine();
			System.out.println(memoList.getMemoList().get(num-1));
			System.out.print("패스워드를 입력하세요: ");
			String password = scan.nextLine();
			if (memoList.getMemoList().get(num-1).getPassword().equals(password)) {
				memoList.getMemoList().remove(num-1);
				System.out.println("삭제가 완료되었습니다!!!");
			}else {
				System.out.println("비밀번호가 일치하지 않습니다!!!");
			}
		}
		
	}

	private static void set() {
		if (memoList.getMemoList().isEmpty()) {
			System.out.println("목록이 비어있습니다!!!");
		}else {
			Scanner scan = new Scanner(System.in);
			System.out.println("수정할 글의 번호를 입력하세요");
			int num = scan.nextInt();
			scan.nextLine();
			System.out.println(memoList.getMemoList().get(num-1));
			System.out.print("패스워드를 입력하세요: ");
			String password = scan.nextLine();
			if (memoList.getMemoList().get(num-1).getPassword().equals(password)) {
				System.out.print("수정할 메모를 입력하세요: ");
				String memo = scan.nextLine().trim();
				memoList.getMemoList().get(num-1).setMemo(memo);
				System.out.println("수정되었습니다!!!!");
			}else {
				System.out.println("비밀번호가 일치하지 않습니다!!!");
			}
		}
		
	}

	private static void show() {
		if (memoList.getMemoList().isEmpty()) {
			System.out.println("목록이 비어있습니다!!!");
		}else {
			System.out.println(memoList);			
		}
	}

	private static void insert() {
		Scanner scan = new Scanner(System.in);
		System.out.print("이름을 입력하세요: ");
		String name = scan.nextLine().trim();
		System.out.print("비밀번호를 입력하세요: ");
		String password = scan.nextLine().trim();
		System.out.print("메모를 입력하세요: ");
		String memo = scan.nextLine().trim();
		MemoVO vo = new MemoVO(name, password, memo);
		
		memoList.addMemo(vo);
		System.out.println("입력이 완료되었습니다.");
		
	}

}
