package com.tjoeun.memoList;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Scanner;

import com.tjoeun.memoList.MemoVO;

public class MemoList {
	
	private ArrayList<MemoVO> MemoList = new ArrayList<>();
	
	public MemoList() {
	}
	
	public ArrayList<MemoVO> getMemoList() {
		return MemoList;
	}
	public void setMemoList(ArrayList<MemoVO> MemoList) {
		this.MemoList = MemoList;
	}
	
	


	@Override
	public String toString() {
		String str = "";
		if (MemoList.size() == 0) {
			str += "저장된 메모가 없습니다\n";
		}else {
			for (int i=0;i<MemoList.size();i++) {
				str += MemoList.get(MemoList.size()-1-i) + "\n";
			}
		}
		return str;
	}
	
	public MemoVO selectMemo(int idx) {
		try {
			return MemoList.get(idx-1);			
		}catch (Exception e) {
			return null;
		}
	}

	public void addMemo(MemoVO vo) {
		MemoList.add(vo);
	}

	public void deleteMemo(int idx) {
		MemoList.remove(idx-1);
		for(int i=0;i<MemoList.size();i++) {
			MemoList.get(i).setIdx(i+1);
		}
		MemoVO.count = MemoList.size();
	}

	public void updateMemo(int idx, String memo) {
		MemoList.get(idx-1).setMemo(memo);
	}
	public void re() {
		for(int i=0;i<MemoList.size();i++) {
			MemoList.get(i).setIdx(i+1);
		}
	}

	public void writeMemo(String filename) {
		Scanner scanner = null;
		PrintWriter printWriter = null;
		
//		String filepath = ".\\src\\com\\tjoeun\\memoList\\" + filename + ".txt";
		String filepath = String.format(".\\src\\com\\tjoeun\\memoList\\%s.txt", filename);
//		System.out.println(filepath);
		try {
			printWriter = new PrintWriter(filepath);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
			/*
			for (int i=0;i<MemoList.size();i++) {
				MemoVO vo = MemoList.get(i);
//				String str = "";
//				str += vo.getIdx() + " ";
//				str += vo.getName().replace(" ", "`") + " ";
//				str += vo.getPassword() + " ";
//				str += vo.getMemo().replace(" ", "`") + " ";
//				//str += (vo.getWriteDate()+"").replace(" ", "`") + " ";
//				str += sdf.format(vo.getWriteDate());
				String str = String.format("%d %s %s %s %s", vo.getIdx(), vo.getName().replace(" ", "`"), vo.getPassword(), vo.getMemo().replace(" ", "`"), sdf.format(vo.getWriteDate()));
//				System.out.println(str);
				printWriter.write(str + "\n");
			}
			*/
			for (MemoVO vo : MemoList) {
				String str = String.format("%d %s %s %s %s", vo.getIdx(), vo.getName().replace(" ", "`"), vo.getPassword(), vo.getMemo().replace(" ", "`"), sdf.format(vo.getWriteDate()));
			}
			System.out.println("파일 생성&입력 성공");
		} catch (FileNotFoundException e) {
			System.out.println("파일 이름이 잘못되었거나 존재하지 않습니다.");
		}finally {
			if (printWriter != null) {
				printWriter.close();				
			}
		}
	}

	public void readMemo(String filename) {
		Scanner scanner = null;
		String filepath = String.format(".\\src\\com\\tjoeun\\memoList\\%s.txt", filename);
		
		try {
			scanner = new Scanner(new File(filepath));
			while (scanner.hasNextLine()) {
				String str = scanner.nextLine().trim();
//				System.out.println(str);
				Scanner scan = new Scanner(str);
				int idx = scan.nextInt();
				String name = scan.next().replace("`", " ");
				String password = scan.next();
				String memo = scan.next().replace("`", " ");
				String temp = scan.nextLine().trim();
				
//				int year = Integer.parseInt(temp.substring(0, 4))-1900;
//				int month = Integer.parseInt(temp.substring(5, 7))-1;
//				int day = Integer.parseInt(temp.substring(8, 10));
//				int hour = Integer.parseInt(temp.substring(11, 13));
//				int min = Integer.parseInt(temp.substring(14, 16));
//				int sec = Integer.parseInt(temp.substring(17));
				
				// split() 메소드 .을 구분자로 하려면 "\\." or "[.]" 사용
				String[] date = temp.split("\\.");
				int year = Integer.parseInt(date[0])-1900;
				int month = Integer.parseInt(date[1])-1;
				int day = Integer.parseInt(date[2]);
				int hour = Integer.parseInt(date[3]);
				int min = Integer.parseInt(date[4]);
				int sec = Integer.parseInt(date[5]);
				
				Date writeDate = new Date(year, month, day, hour, min, sec);
//				System.out.println(writeDate);
				
//				MemoVO vo = new MemoVO();
//				vo.setIdx(idx);
//				vo.setName(name);
//				vo.setPassword(password);
//				vo.setMemo(memo);
//				vo.setWriteDate(writeDate);
				
//				MemoVO vo = new MemoVO(name, password, memo);
//				vo.setIdx(idx);
//				vo.setWriteDate(writeDate);
				
				MemoVO vo = new MemoVO(idx, name, password, memo, writeDate);
				
				MemoList.add(vo);
			}
			System.out.println("파일 읽기 성공");
		} catch (FileNotFoundException e) {
			System.out.println("파일 경로가 잘못되었거나 파일이 존재하지 않습니다.");
		}finally {
			if (scanner != null) {
				scanner.close();
			}
		}
		
		
	}

}
