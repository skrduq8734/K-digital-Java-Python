package k20230410;

public class RankingTest2 {

	public static void main(String[] args) {

		int[] score = {80, 100, 70, 95, 94};
		
		int[] rank = new int[score.length];
		for (int i =0; i<rank.length;i++) {
			rank[i] = 1;
		}
		//System.out.println(Arrays.toString(rank));
		
		for (int i=0;i<score.length-1;i++) {
			for (int j=i+1;j<score.length;j++) {
				if (score[i] < score[j]) {
					rank[i]++;
				}
				else if (score[i] > score[j]) {
					rank[j]++;
				}
			}
		}
		
		for (int i=0;i<score.length;i++) {
			System.out.printf("%3d 점은 %d등 입니다. ", score[i], rank[i]);
			for (int j = 0; j < score[i]/10;j++) {
				System.out.print("★");
			}
			if(score[i]%10 >4) {
				System.out.print("☆");
			}
			System.out.println();
		}

	}

}
