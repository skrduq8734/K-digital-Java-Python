package k20230410;
import java.util.Arrays;
import java.util.Scanner;

public class Fibonacci {

	public static void main(String[] args) {
		 
//		Scanner scan = new Scanner(System.in);
//		int N = scan.nextInt();
// 
//		int[] fibonacci = new int[N + 1];
// 
//		for(int i = 0; i < fibonacci.length; i++) {
//			
//			if(i == 0) fibonacci[0] = 0;
//			else if(i == 1) fibonacci[1] = 1;            
//			else fibonacci[i] = fibonacci[i - 1] + fibonacci[i - 2];
//		}
//        
//		System.out.println(fibonacci[N]);
		int a=1;
		int b=1;
		int y=2;
		
		Scanner scan = new Scanner(System.in);
		System.out.print("피보나치 수열의 합계를 계산할 항수를 입력하세요: ");
		int n = scan.nextInt();
		
		int[] arry = new int[n];
		int cnt = 0;
		for (int i=3;i<=n;i++) {
			int c = a + b;
			arry[cnt++] = c;
			
			y += c;
			a=b;
			b=c;
		}
		
		System.out.print("피보나치 수열의 "+n+"번째 항 까지의 합계: " + y +" = ");
		System.out.println(Arrays.toString(arry));
		System.out.println("배열의 크기: " + arry.length);
		

		
	}

}
