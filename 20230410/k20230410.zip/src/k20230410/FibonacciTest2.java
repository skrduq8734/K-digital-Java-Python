package k20230410;

import java.util.Arrays;
import java.util.Scanner;

public class FibonacciTest2 {
		public static void main(String[] args) {
			
			Scanner scan = new Scanner(System.in);
			System.out.print("피보나치 수열의 합계를 계산할 항수를 입력하세요: ");
			int n = scan.nextInt();
			
			int[] fibo = new int[n];
			System.out.println("배열의 크기: " + fibo.length);
			
			fibo[0] = 1;
			fibo[1] = 1;
			int y = 2;
			
			for (int i = 2 ; i < n ; i++) {
				fibo[i] = fibo[i-2]+fibo[i-1];
				y += fibo[i];
			}
			System.out.println(Arrays.toString(fibo));
			System.out.print("합계: " + y + " = ");
			
			for (int i = 0 ; i < fibo.length - 1; i++) {
				System.out.print(fibo[i] + " + ");
			}
			System.out.println(fibo[fibo.length -1]);
			
		}
}
