package k20230410;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class LottoTest2 {

	public static void main(String[] args) {
		
		Random random = new Random();
		int[] lotto = new int[45];
		for (int i=0; i<lotto.length; i++) {
			lotto[i] = i + 1;
		}
		Scanner scanner = new Scanner(System.in);
		System.out.print("복권 구매 금액을 입력하세요: ");
		int won = scanner.nextInt();
		int cnt = won/1000;
		
		for(int i=0;i<cnt;i++) {
			System.out.printf("------------------%d번째---------------\n", i+1);
			for (int k=0; k<1000000; k++) {
				int r = random.nextInt(44) + 1;
				int temp = lotto[0];
				lotto[0] = lotto[r];
				lotto[r] = temp;
			}
			System.out.print("1등 번호: ");
			int[] data = new int[6];
			for (int j=0; j<6; j++) {
				data[j] = lotto[j];
				
			}
			
//			Arrays.sort(data);
			int tmp = 0;
			for (int q =0; q<data.length-1;q++) {
				for(int j=q+1;j<data.length;j++) {
					if (data[q] > data[j]) {
						tmp = data[j];
						data[j] = data[q];
						data[q]= tmp;
					}
				}
			}
			
			for (int j=0; j<6; j++) {
				System.out.printf("%02d ", data[j]);
				
			}
			System.out.println();
		}

		
	}
	
}




