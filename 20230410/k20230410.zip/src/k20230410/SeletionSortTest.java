package k20230410;

import java.util.Arrays;

public class SeletionSortTest {

	public static void main(String[] args) {

//		for (int i=0;i<4;i++) {
//			for (int j=i+1;j<5;j++) {
//				System.out.printf("i = %d, j = %d\n", i, j);
//			}
//			System.out.println(" ");
//		}
		
		int data[] = {8,3,4,9,1};
		int tmp = 0;
		for (int i =0; i<data.length-1;i++) {
			for(int j=i+1;j<data.length;j++) {
				if (data[i] > data[j]) {
					tmp = data[j];
					data[j] = data[i];
					data[i]= tmp;
				}
			}

			System.out.println(i+1+"회전 결과: "+Arrays.toString(data));
		}
		

	}

}
