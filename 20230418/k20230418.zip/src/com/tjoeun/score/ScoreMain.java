package com.tjoeun.score;

public class ScoreMain {
	public static void main(String[] args) {
		ScoreVO score1 = new ScoreVO("홍성우", 95, 88, 92);
		ScoreVO score2 = new ScoreVO("가나다", 71, 86, 63);
		ScoreVO score3 = new ScoreVO("라나라", 78, 49, 56);
		ScoreVO score4 = new ScoreVO("기라이", 69, 98, 97);
		ScoreVO score5 = new ScoreVO("카이내", 83, 93, 65);
		
		ScoreList scoreList = new ScoreList();
		scoreList.addscore(score1);
		scoreList.addscore(score2);
		scoreList.addscore(score3);
		scoreList.addscore(score4);
		scoreList.addscore(score5);
		System.out.println(scoreList);
		
	}

}
