package com.tjoeun.score;

import java.util.ArrayList;

public class ScoreList {
	
	private ArrayList<ScoreVO> ScoreList = new ArrayList<>();
	
	public ScoreList() {
	}
	
	public ArrayList<ScoreVO> getScoreList() {
		return ScoreList;
	}
	public void setScoreList(ArrayList<ScoreVO> ScoreList) {
		this.ScoreList = ScoreList;
	}
	
	
	@Override
	public String toString() {
		for (int i = 0; i<ScoreList.size() - 1;i++) {
			for (int j = i+1; j<ScoreList.size();j++) {
				if (ScoreList.get(i).getTotal()>ScoreList.get(j).getTotal()) {
					ScoreList.get(j).setRank(ScoreList.get(j).getRank() + 1);
				}else if (ScoreList.get(i).getTotal() < ScoreList.get(j).getTotal()) {
					ScoreList.get(i).setRank(ScoreList.get(i).getRank() + 1);
				}
			}
		}
		
		String str = "";
		str += "====================================================\n";
		str += " 번호  이름  Java  Jsp  Spring Total mean 석차\n";
		str += "====================================================\n";

		for (ScoreVO vo : ScoreList) {
			str += vo + "\n";
			
		}
		str += "====================================================\n";
		return str;
	}

	public void addscore(ScoreVO score) {
		ScoreList.add(score);
	}

}
