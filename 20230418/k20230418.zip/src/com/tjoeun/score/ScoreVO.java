package com.tjoeun.score;

import java.text.DecimalFormat;

public class ScoreVO {
	
	public static int count;
	
	private int idx; // 일련번호 => 자동증가
	private String name; // 이름
	private int java; // java 점수
	private int jsp; // jsp 점수
	private int spring; // spring 점수
	private int total; // 총점
	private double mean; // 평균
	private int rank = 1; // 석차
	
	public ScoreVO() {
		// TODO Auto-generated constructor stub
	}

	public ScoreVO(String name, int java, int jsp, int spring) {
		super();
		idx = ++count;
		this.name = name;
		this.java = java;
		this.jsp = jsp;
		this.spring = spring;
		this.total = java + jsp + spring;
		mean = (double) total / 3;
	}
	

	public static int getCount() {
		return count;
	}
	public static void setCount(int count) {
		ScoreVO.count = count;
	}
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getJava() {
		return java;
	}
	public void setJava(int java) {
		this.java = java;
	}
	public int getJsp() {
		return jsp;
	}
	public void setJsp(int jsp) {
		this.jsp = jsp;
	}
	public int getSpring() {
		return spring;
	}
	public void setSpring(int spring) {
		this.spring = spring;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public double getMean() {
		return mean;
	}
	public void setMean(double mean) {
		this.mean = mean;
	}
	public int getRank() {
		return rank;
	}
	public void setRank(int rank) {
		this.rank = rank;
	}

	@Override
	public String toString() {
//		DecimalFormat df = new DecimalFormat("#.##");
//		return "ScoreVO [idx=" + idx + ", name=" + name + ", java=" + java + ", jsp=" + jsp + ", spring=" + spring
//				+ ", total=" + total + ", mean=" + df.format(mean) + ", rank=" + rank + "]";
		return String.format("   %d  %s %3d  %3d   %3d    %3d %6.2f %d", idx, name, java, jsp, spring, total, mean, rank);
	}
	

}
