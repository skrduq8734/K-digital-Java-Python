package k20230411;

import java.util.Arrays;

public class BubbleSortEarlyStopTest {

	public static void main(String[] args) {

		int data[] = {9,1,2,6,4};
		for (int i = 0; i < data.length - 1 ; i++) {
			boolean isFlag = false;							// A
			for(int j = 0;j<data.length - 1 - i; j++) {
				if (data[j] > data[j + 1]) {
					int tmp = data[j + 1];
					data[j + 1] = data[j];
					data[j]= tmp;
					isFlag = true;							// B		
				}
			}
			if (!isFlag) {									// C
				break;
			}
			System.out.print(i + "회전 버블정렬 결과값: " + Arrays.toString(data));
			System.out.println();
		}

	}

}
