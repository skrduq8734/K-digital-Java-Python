package k20230411;

public class WhileTest {

	public static void main(String[] args) {
		
		int sum = 0;
		for (int i = 0; i<11;i++){
			sum += i;
		}
		System.out.println("1 ~ 10의 합계: "+ sum);
		
		sum = 0;
		int i = 0;
		while(i<11) {
			sum += i;
			i++;
		}
		System.out.println("1 ~ 10의 합계: "+ sum);
		
		sum = 0;
		i = 0;
		do {
			sum += i;
			i++;
		} while(i<11);
		System.out.println("1 ~ 10의 합계: "+ sum);
		
	}

}
