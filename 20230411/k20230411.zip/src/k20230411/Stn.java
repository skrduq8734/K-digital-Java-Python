package k20230411;

import java.util.Arrays;

public class Stn {

	public static void main(String[] args) {

		int[] data = {4, 1, 3, 5, 2};
		
//		int max = 0;
//		int min = 99;
//		
//		for (int i=0;i<data.length;i++) {
//			if (data[i]>max){
//				max = data[i];
//			}
//			if (data[i]<min) {
//				min = data[i];
//			}
//		}
		
//		int max = data[0];
//		int min = data[0];
//		
//		for (int i=1;i<data.length;i++) {
//			
//			if (data[i]>max){
//			max = data[i];
//			}
//			else if (data[i]<min) {
//				min = data[i];
//			}		
//		}	
//		System.out.printf("최대값 %d, 최소값: %d\n", max, min);
//		int sum=0;
//		for (int i = 0; i<data.length;i++) {
//			sum += data[i];
//		}
//		sum = sum - max - min;
//		double avg = (double) sum / (data.length - 2); 
//		System.out.print("합계: " + sum);
//		System.out.println(", 평균: " + avg);
		
		for (int i=0; i<data.length-1; i++) {
			boolean flag = true;
			for (int j=0; j<data.length-1-i; j++) {
				if (data[j] > data[j + 1]) {
					int temp = data[j];
					data[j] = data[j + 1];
					data[j + 1] = temp;
					flag = false;
				}
			}
			if (flag) {
				break;
			}
		}
		System.out.println(Arrays.toString(data));
		
		int sum=0;
		for (int i=1;i<data.length-1;i++) {
			sum += data[i];
		}
		System.out.println(sum);
		double avg = sum/(double) (data.length-2);
		System.out.println(avg);
		double stn = 0;
		
		for (int i=1; i<data.length-1;i++) {
			double tmp =  data[i] - avg;
//			stn += (tmp*tmp);
			stn += Math.pow(tmp, 2);
		}
		System.out.println(stn);
		double var = stn / (data.length - 2);
		System.out.printf("최대값과 최소값을 제외한 나머지 데이터의 분산: %.2f\n", var);
		double std = Math.sqrt(var);
		System.out.printf("최대값과 최소값을 제외한 나머지 데이터의 표준편차: %.2f\n", std);
	}
}
