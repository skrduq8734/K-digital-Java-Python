package k20230411;

import java.util.Scanner;

public class MenuTest {

	public static void main(String[] args) {
		boolean isFlag = true;
		int num = 0;
		do {
			System.out.println("================================");
			System.out.println("1.입력 2.목록보기 3.수정 4.삭제 5.종료 ");
			System.out.println("================================");
			System.out.print("원하는 메뉴를 입력하세요: ");
			try (Scanner scan = new Scanner(System.in)) {
				num
				= scan.nextInt();
			}
			switch(num) {
			case 1:
				System.out.println("입력");
				break;
			case 2:
				System.out.println("목록보기");
				break;
			case 3:
				System.out.println("수정");
				break;
			case 4:
				System.out.println("삭제");
				break;
			case 5:
				System.out.println("종료");
				//System.exit(0); // 프로그램 강제 종료
				isFlag = false;
				break;
			default:
				System.out.println("잘못 입력하셨습니다.");
				break;
			}
		}while(isFlag);
				
		
	}

}
