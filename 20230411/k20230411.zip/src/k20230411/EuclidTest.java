package k20230411;

import java.util.Scanner;

public class EuclidTest {

	public static void main(String[] args) {
		
		int num1 = 0;
		int num2 = 0;
		int min = 0;
		int max = 0;
		boolean isFlag = true;
		System.out.print("두 값을 입력하세요: ");
		try (Scanner scan = new Scanner(System.in)) {
			num1 = scan.nextInt();
			num2 = scan.nextInt();
		}
		if (num1 < num2) {
			int tmp = num2;
			num2 = num1;
			num1 = tmp;
		}
		int a = num1 * num2;
		while(isFlag) {
			if (num1 % num2 == 0) {
				min = num2;
				isFlag = false;
			}else {
				int tmp = num2;
				num2 = (num1 % num2);
				num1 = tmp;
			}
		}
		max = a / min;
		System.out.printf("최대공약수: %d\n최소공배수: %d\n", min, max);

	}

}
