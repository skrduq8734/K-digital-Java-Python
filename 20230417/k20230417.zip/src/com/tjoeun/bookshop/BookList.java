package com.tjoeun.bookshop;

import java.text.DecimalFormat;
import java.util.Arrays;


// 여러권의 책 정보를 기억하는 클래스
public class BookList {
	// 1. 필드 선언
	private BookVO[] bookList;	// 여러권의 책 정보를 기억할 배열을 선언 -> null
	private int size;			// 배열의 크기
	private int index;			// 배열의 인덱스, 저장된 데이터의 개수
	
	// 2. 생성자 선언
	public BookList() {
		size = 10;
		bookList = new BookVO[size];
	}	
	public BookList(int size) {
		super();
		this.size = size;
		bookList = new BookVO[size];
	}
	
	// getters & setters 선언
	public BookVO[] getBookList() {
		return bookList;
	}
	public void setBookList(BookVO[] bookList) {
		this.bookList = bookList;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	@Override
	public String toString() {
		//return "BookList [bookList=" + Arrays.toString(bookList) + ", size=" + size + ", index=" + index + "]";
		String str = "";
		str += "===========================\n";
		str += " 도서명 저자 출판사 출판일 가격\n";
		str += "===========================\n";
		double sum = 0.0;
//		for (int i=0;i<size;i++) {
//			str += bookList[i] + "\n";
//		}
//		for (int i=0;i<index;i++) {
//			str += bookList[i] + "\n";
//		}
//		for (int i=0;i<size;i++) {
//			if (bookList[i] == null) {
//				break;
//			}else {
//				str += bookList[i] + "\n";				
//			}
//		}
		for (BookVO vo : bookList) {
			if (vo == null) {
				break;
			}
			str += vo + "\n";
			sum += vo.getPrice();
		}
		
		DecimalFormat df = new DecimalFormat("$#,##0.00");
		str += "===========================\n";
		str += "합계 금액: " + df.format(sum) + "\n";
		str += "===========================\n";
		return str;
	}
	
	// BookList 클래스의 bookList 배열에 인수로 념겨받은 도서 정보를 저장하는 메소드
	public void addBook(BookVO book) {
//		if (index < size) {
//			bookList[index++] = book;
//			System.out.println(index+"번째 도서정보 저장완료!!!");
//		}
//		else {
//			System.out.println("배열이 가득차서 "+ book.getAuthor() +"의 도서 정보를 저장할 수 없습니다.");
//			JOptionPane.showInternalMessageDialog(null, book);
//		}
		
		// 예외처리 try ~ catch ~ finally
		try {
			bookList[index++] = book;	
		}catch (ArrayIndexOutOfBoundsException e){
			System.out.println("배열이 가득차서 추가할 수 없습니다.");
			// getMessage(): 예외 메세지를 얻어옴
			System.out.println(e.getMessage());
			// printStackTrace(): 실행 역순으로 보여줌
			e.printStackTrace();		
		}catch(Exception e) {
			// 모든 예외 처리
			// 다른 예외처리 아래적어야함. 만약 위에 적으면 아래 예외처리는 모두 의미없는 코드
			System.out.println("예외상황 발생!");
		}finally {
			System.out.println("파이널 실행");
		}
	}
	
	
}
