package com.tjoeun.bookshop;

import java.net.CookieHandler;
import java.util.Date;

public class BookshopMain {
	public static void main(String[] args) {
		
		BookVO vo = new BookVO();	// 생성자가 없으면 기본생성자 자동생성
		System.out.println(vo);		// 자바가 객체를 구분하기위한 해시코드
		System.out.println(vo.toString());	// 클래스로 만든 객체를 출력하면 자동으로 toString() 메소드가 실행된다.
		
		// 출판일은 재사용 할일이 없기 떄문에 익명으로 new하여 사용한다.
		BookVO book1 = new BookVO("java", "홍길동", "더조은출판사", new Date(2020, 5, 20), 35000);
		System.out.println(book1);
		
		BookVO book2 = new BookVO("java", "홍길가", "더조은출판사", new Date(2020, 5, 20), 35000);
		BookVO book3 = new BookVO("java", "홍길나", "더조은출판사", new Date(2020, 5, 20), 35000);
		BookVO book4 = new BookVO("java", "홍길다", "더조은출판사", new Date(2020, 5, 20), 35000);
		BookVO book5 = new BookVO("java", "홍길라", "더조은출판사", new Date(2020, 5, 20), 35000);
		BookVO book6 = new BookVO("java", "홍길마", "더조은출판사", new Date(2020, 5, 20), 35000);
		
		// "=="을 사용한 비교는 기본자료형 8가지와 null만 가능하다
		// 클래스로 만든 객체를 "=="을 사용해 비교하면 객체의 주소를 비교한다
		// equals()를 사용하기 위해선 override해야하고 hashcode()도 override해야한다 
		
		BookList bookList = new BookList(5);
		bookList.addBook(book1);
		bookList.addBook(book2);
		bookList.addBook(book3);
//		bookList.addBook(book4);
//		bookList.addBook(book5);
//		bookList.addBook(book6);
		System.out.println(bookList);
	}

}
