package com.tjoeun.bookshop;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;

// 구조체는 퍼블릭이여야한다. 클래스라 프라이빗
// 도서정보 1건을 기억하는 클래스
public class BookVO {

	// 데이터를 기억할 멤버변수(필드) 4byte fullword
	// word가 모이면 field
	
	private String title; // 도서명
	private String author; // 저자
	private String publisher; // 출판사
	private Date writeDate; // 출판일
	// 위의 4개 모두 클래스라 자동초기화 null
	private double price; // 가격
	
	// 생성자 이름은 클래스 이름과 같아야 함
	// 프로그래머가 생성자를 선언하면 기본생성자를 생성하지 않음
	// 생성자는 리턴타입이 없고 내부에서 리턴도 안한다.
	// 생성자는 객체가 생성될 떄 자동으로 실행되고 필드에 데이터 초기화를 목적으로 사용한다.
	public BookVO() {
		//System.out.println("기본 생성자 실행.");
		this("","","",new Date(), 0);
	}
	
	// 데이터를 넘겨받아 필드를 초기화시키는 생성자
	public BookVO(String title, String author, String publisher, Date writeDate, double price) {
		// super()와 this()는 반드시 생성자의 첫문장이어야 한다. 둘다 쓰고싶으면 this()만 쓰면 슈퍼는 자동생성
		super();	// 생략해도 자바 컴파일러가 자동으로 붙여준다. 부모 클래스의 이름 = 부모클래스 생성자
		this.title = title;
		this.author = author;
		this.publisher = publisher;
		//this.writeDate = writeDate;
		this.writeDate = writeDate;
		this.writeDate.setYear(writeDate.getYear() - 1900);
		this.writeDate.setMonth(writeDate.getMonth() - 1);
		this.price = price;
	}

	// getters & setters 메소드는 private 권한으로 선언된 필드를 클래스 외부에서 접근할수 있도록 예외규정을 만든
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public Date getWriteDate() {
		return writeDate;
	}

	public void setWriteDate(Date writeDate) {
		this.writeDate = writeDate;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	// 클래스 객체에 저장된 데이터를 보려면 toString() 메소드를 Override해야 한다.
	@Override
	public String toString() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd(E)");
		// NumberFormat: 클래스로 숫자 출력 서식 지정하기
		//NumberFormat nf = NumberFormat.getNumberInstance(); -> 천단위 구분 기호
		//NumberFormat nf = NumberFormat.getCurrencyInstance(Locale.ITALIAN); -> 통화표시 + 천단위 구분 기호
		//NumberFormat nf = NumberFormat.getPercentInstance(); -> 백분율, 자동으로 100이 곱해짐
		
		// 만들어서 지정하기
		// DecimalFormat df = new DecimalFormat("출력서식"); -> 출력 서식에는 "#,##0"을 입력하고 앞뒤로 서식에 필요한 문자를 직접 입력해서 만든다.
		// DecimalFormat df = new DecimalFormat("#,##0"); // == NumberFormat nf = NumberFormat.getNumberInstance();
		// DecimalFormat df = new DecimalFormat("￦#,##0"); // == NumberFormat nf = NumberFormat.getCurrencyInstance();
		// DecimalFormat df = new DecimalFormat("#,##0%"); // == NumberFormat nf = NumberFormat.getPercentInstance();
		// DecimalFormat df = new DecimalFormat("#,##0.00"); // -> 보고싶은 자리수만큼 .찍고 0붙이기
		DecimalFormat df = new DecimalFormat("일금 #,##0원");
		
//		return "BookVO [title=" + title + ", author=" + author + ", publisher=" + publisher + ","
//				+ " writeDate=" + sdf.format(writeDate) + ", price=" + df.format(price) + "]";
		//return title + ","+author + ","+ publisher + ","+ sdf.format(writeDate)+ "," +df.format(price);
		return String.format("%s %s %s %s %s", title, author, publisher, sdf.format(writeDate), df.format(price));
	}
	
	// 객체에 저장된 데이터가 같으면 같은 hashcode()를 만들어준다.
	@Override
	public int hashCode() {
		return Objects.hash(author, price, publisher, title, writeDate);
	}

	// 객체의 필드에 저장된 실제 데이터끼리 비교할 수 있도록 만들어준다.
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BookVO other = (BookVO) obj;
		return Objects.equals(author, other.author)
				&& Double.doubleToLongBits(price) == Double.doubleToLongBits(other.price)
				&& Objects.equals(publisher, other.publisher) && Objects.equals(title, other.title)
				&& Objects.equals(writeDate, other.writeDate);
	}
	
	
}
