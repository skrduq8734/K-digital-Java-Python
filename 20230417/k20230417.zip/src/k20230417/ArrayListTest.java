package k20230417;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class ArrayListTest {

	public static void main(String[] args) {

		int[] data = new int[10];
		
		for (int i =0;i<10;i++) {
			data[i] = i+1;
		}
		for (int i =0;i<10;i++) {
			System.out.printf("data[%d] = %2d\n", i, data[i]);
		}
//		for (int i =10;i<20;i++) {		// 범위 벗어나면 에러
//			data[i] = i+1;
//		}
		
		ArrayList<Integer> list = new ArrayList<>();
		for (int i =0;i<10;i++) {
			list.add(i+1);
		}
		for (int i =0;i<10;i++) {
			System.out.printf("list.get(%d) = %2d\n", i, list.get(i));
		}
		
	}

}
