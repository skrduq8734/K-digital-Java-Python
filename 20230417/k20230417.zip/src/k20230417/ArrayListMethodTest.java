package k20230417;

import java.util.ArrayList;

public class ArrayListMethodTest {

	public static void main(String[] args) {

		ArrayList<String> list = new ArrayList<>();
		list.add("홍성우");
		System.out.println(list.size() + ": " + list);
		list.add("가나다");
		System.out.println(list.size() + ": " + list);
		
		list.add(1, "손오공");
		System.out.println(list.size() + ": " + list);
		
		// 향상된 for
		for (String str :  list) {
			System.out.println(str);
		}
		
		

	}

}
