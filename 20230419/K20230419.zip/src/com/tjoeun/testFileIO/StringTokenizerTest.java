package com.tjoeun.testFileIO;

import java.util.Arrays;
import java.util.StringTokenizer;

public class StringTokenizerTest {
	
	public static void main(String[] args) {
		
		/*
		String str = "010-1234-5678";
		String[] phoneNo = str.split("-");
		System.out.println(Arrays.toString(phoneNo));
		
		// split() 메소드는 구분자를 2개이상 지정 불가
		str = "사과 배 복숭아    밤 대추";
		String[] date = str.split("	");
		System.out.println(Arrays.toString(date));
		*/
		
		// StringTokenizer 클래스는 사용자 지정 구분자로 분리
		// 생략시 공백과 탭을 기본 구분자로 사용
		// 분리된 데이터는 token
		String str = "사과 배 복숭아	밤 대추";
		StringTokenizer st1 = new StringTokenizer(str);
		
		while (st1.hasMoreTokens()) {
			System.out.println(st1.nextToken());
		}
		System.out.println("=============================");
		str = "사과,배,복숭아.밤,대추";
		// 구분자 여러개 지정 가능
		StringTokenizer st2 = new StringTokenizer(str, ",.");
		
		while (st2.hasMoreTokens()) {
			System.out.println(st2.nextToken());
		}
		System.out.println("=============================");
		str = "사과=1000,배=2000,복숭아=3000,밤=4000,대추=5000";
		// 3번째 인자로 true를 넘겨주면 구분자도 토큰으로 인식한다.
		StringTokenizer st3 = new StringTokenizer(str, "=,", true);
		
		while (st3.hasMoreTokens()) {
			System.out.println(st3.nextToken());
		}
		
	}

}
