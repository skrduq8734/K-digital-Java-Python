package com.tjoeun.testFileIO;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FilePermission;
import java.util.Arrays;
import java.util.Scanner;

public class TextFileReadTest2 {
	public static void main(String[] args) {
		
		Scanner scanner= null;
		
		String filepath = ".\\src\\com\\tjoeun\\testFileIO\\input.txt";
		
		try {
			scanner = new Scanner(new File(filepath));
			
			while(scanner.hasNextLine()) {
				String str = scanner.nextLine().trim();
				if (str.length() != 0) {
					System.out.println(Arrays.toString(str.split(" ")));
					
					int i = 0;
					boolean b = false;
					double d = 0;
					String s = "";
					
					Scanner scan = new Scanner(str);
					while (scan.hasNext()) {
						if (scan.hasNextInt()) {
							i = scan.nextInt();							
						}else if(scan.hasNextBoolean()) {
							b = scan.nextBoolean();							
						}else if(scan.hasNextDouble()) {
							d = scan.nextDouble();							
						}else {
							s = scan.next();							
						}
					}
					System.out.println("i: " + i);
					System.out.println("b: " + b);
					System.out.println("d: " + d);
					System.out.println("s: " + s);
				}
			}
			System.out.println("읽기완료");
			
		} catch (FileNotFoundException e) {
			System.out.println("파일 경로가 잘못되었거나 파일이 존재하지 않습니다.");
		}finally {
			if (scanner != null) {
				scanner.close();
			}
		}		
	}
}
