package com.tjoeun.testFileIO;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class TextFileWirteTest {
	
	public static void main(String[] args) {
		
		Scanner scanner = null;
		PrintWriter printWriter = null;	// 텍스트 파일로 출력에 사용할 PrintWriter
		
		// 절대경로
		//String fliepath = "C:\\project\\java\\workspace\\K20230419\\src\\com\\tjoeun\\testFileIO\\out.txt";
		
		// 상대경로
		String fliepath = ".\\src\\com\\tjoeun\\testFileIO\\out.txt";
		
		// PrintWriter 클래스의 생성자로 출력 파일의 경로와 이름을 지정해서 출력 파일을 만든다.
		try {
			printWriter = new PrintWriter(fliepath);
			scanner = new Scanner(System.in);
			
			// QUIT가 입력될 때 까지 반복하며 키보드로 입력한 데이터를 파일에 저장한다.
			while(true) {
				System.out.print(">>> ");
				String str = scanner.nextLine().trim();
				
				if (str.toUpperCase().equals("QUIT")) {
					break;
				}
				if (str.length() !=0) {
					printWriter.write(str + "\n");					
				}
			}
			System.out.println("저장완료!!!");
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();	// 에러 메세지와 오류위치 역순 출력
		}finally {
			printWriter.close();
		}
		
		
	}

}
