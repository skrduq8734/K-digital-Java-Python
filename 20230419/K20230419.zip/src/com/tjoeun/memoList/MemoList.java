package com.tjoeun.memoList;

import java.util.ArrayList;
import java.util.Collections;

import com.tjoeun.memoList.MemoVO;

public class MemoList {
	
	private ArrayList<MemoVO> MemoList = new ArrayList<>();
	
	public MemoList() {
	}
	
	public ArrayList<MemoVO> getMemoList() {
		return MemoList;
	}
	public void setMemoList(ArrayList<MemoVO> MemoList) {
		this.MemoList = MemoList;
	}
	
	


	@Override
	public String toString() {
//		Collections.reverse(MemoList);
//		return MemoList + "";
		String str = "";
		if (MemoList.size() == 0) {
			str += "저장된 메모가 없습니다\n";
		}else {
//			for (int i=0;i<MemoList.size();i++) {
//				str += MemoList.get(MemoList.size() -1 -i) + "\n";
//			}
//			for (int i = MemoList.size() - 1; i >= 0; i--) {
//	            str += MemoList.get(i) + "\n"; // 역순으로 MemoList의 요소들을 문자열로 변환하여 str에 추가
//	        }
			for (int i=0;i<MemoList.size();i++) {
				str += MemoList.get(MemoList.size()-1-i) + "\n";
			}
		}
		return str;
	}
	
	public MemoVO selectMemo(int idx) {
		try {
			return MemoList.get(idx-1);			
		}catch (Exception e) {
			return null;
		}
	}

	public void addMemo(MemoVO vo) {
		MemoList.add(vo);
		//re();
	}

	public void deleteMemo(int idx) {
		MemoList.remove(idx-1);
		for(int i=0;i<MemoList.size();i++) {
			MemoList.get(i).setIdx(i+1);
		}
		MemoVO.count = MemoList.size();
		//MemoVO.setCount(MemoVO.getCount()-1);
		//re();
	}

	public void updateMemo(int idx, String memo) {
		MemoList.get(idx-1).setMemo(memo);
	}
	public void re() {
		for(int i=0;i<MemoList.size();i++) {
			MemoList.get(i).setIdx(i+1);
		}
	}

}
