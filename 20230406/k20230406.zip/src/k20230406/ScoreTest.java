package k20230406;

import java.util.Scanner;

public class ScoreTest {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
//		System.out.print("java 점수: ");
//		int java = scan.nextInt();
//		System.out.print("jsp 점수: ");
//		int jsp = scan.nextInt();
//		System.out.print("spring 점수: ");
//		int spring = scan.nextInt();
		
		System.out.print("3과목 점수를 입력하세요: ");
		int java = scan.nextInt();
		int jsp = scan.nextInt();
		int spring = scan.nextInt();
		
		int total = java + jsp + spring;
		double average = (double) total / 3;
		System.out.println("총점: " + total + "점, 평균: " + average);
		System.out.printf("총점: %3d점, 평균: %6.2f\n", total, average);
		
		
		if (average < 60){
			System.out.println("F 입니다.");
		}
		else if (average < 70){
			System.out.println("D 입니다.");
		}
		else if (average < 80){
			System.out.println("C 입니다.");
		}
		else if (average < 90){
			System.out.println("B 입니다.");
		}
		else{
			System.out.println("A 입니다.");
		}

	}

}
