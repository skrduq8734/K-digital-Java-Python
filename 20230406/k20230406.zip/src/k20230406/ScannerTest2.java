package k20230406;

import java.util.Scanner;

public class ScannerTest2 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.print("나이: ");
		int age = scan.nextInt();
		
		// 버퍼 비워야함
		scan.nextLine();
		
		System.out.print("이름: ");
		String name = scan.nextLine();
		
		System.out.println(name + "님은 " + age +"살 입니다.");
		System.out.println(name + "님은 내년에 " + (age + 1) +"살 입니다.");
		
	}

}
