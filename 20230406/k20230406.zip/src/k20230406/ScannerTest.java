package k20230406;

import java.util.Scanner;

public class ScannerTest {

	public static void main(String[] args) {

		// 변수
		int num = 0;
		System.out.println(num);

		// 불필요한 import 제거 ctrl + shift + o

		// 코드정렬 ctrl + shift + f or ctrl + i

		// 클래스로 만든 변수 = 객체
		
		Scanner scanner = new Scanner(System.in);
		
		// next 한 단어 입력
		// neatLine 한 줄 입력
		//	-> 키보드 버퍼가 비어있어야 입력대기
		
		System.out.print("주소: ");
		String addr = scanner.nextLine();
		
		System.out.print("이름: ");
		String name = scanner.nextLine();
		
		System.out.println(name + "님은" + addr + "에 삽니다.");
		
		

	}

}
