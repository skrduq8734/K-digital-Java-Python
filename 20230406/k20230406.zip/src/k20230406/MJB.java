package k20230406;

import java.util.Random;
import java.util.Scanner;

public class MJB {

	public static void main(String[] args) {

		Random random = new Random();
		int cpu = random.nextInt(3) + 1;
		
		System.out.print("가위(1) 바위(2) 보(3): ");
		Scanner scan = new Scanner(System.in);
		int user = scan.nextInt();
		
		System.out.print("컴퓨터가 고른 번호: " + cpu + "\n내가 고른 번호: " + user + "\n");
		
//		if (cpu == 1) {
//			if (user == 1) {
//				System.err.println("비겼습니다!!!");
//			}
//			else if (user == 2) {
//				System.err.println("이겼습니다!!!");
//			}
//			else if (user == 3) {
//				System.err.println("졌습니다!!!");
//			}
//		}
//		else if (cpu == 2) {
//			if (user == 1) {
//				System.err.println("졌습니다!!!");
//			}
//			else if (user == 2) {
//				System.err.println("비겼습니다!!!");
//			}
//			else if (user == 3) {
//				System.err.println("이겼습니다!!!");
//			}
//		}
//		else if (cpu == 3) {
//			if (user == 1) {
//				System.err.println("이겼습니다!!!");
//			}
//			else if (user == 2) {
//				System.err.println("졌겼습니다!!!");
//			}
//			else if (user == 3) {
//				System.err.println("비겼습니다!!!");
//			}
//		}
		
		if (cpu == user) {
			System.out.println("비겼습니다!!!");
		}
		else if ((cpu == 1 && user == 2) || (cpu == 2 && user == 3) || (cpu == 3 && user == 1)) {
			System.out.println("이겼습니다!!!");
		}
		else {
			System.out.println("졌습니다!!!");
		}
		

	}

}
