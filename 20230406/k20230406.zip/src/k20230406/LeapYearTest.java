package k20230406;

import java.util.Scanner;

public class LeapYearTest {

	public static void main(String[] args) {

//		Scanner scan = new Scanner(System.in);
//		System.out.print("윤년, 평년을 판단할 년도를 입력하세요: ");
//		int year = scan.nextInt();
//		
//		// 논리값을 기억하는 변수나 리턴 타입이 논리값인 메소드의 이름은 "is"로 시작하는게 관행이다.
//		boolean isLeapYear = year % 4 == 0 && year % 100 != 0 || year % 400 == 0;
//		
//		//if ((year % 4 == 0 && year % 100 != 0) || year % 400 ==0) {
//		if (isLeapYear) {
//			System.out.printf("%d년은 윤년입니다.\n", year);
//		}
//		else {
//			System.out.printf("%d년은 평년입니다.\n", year);
//		}
//		
//		//System.out.println(year + "년은 " + (year % 4 == 0 &&year % 100 != 0 || year % 400 ==0? "윤" : "평") + "년입니다.");
//		System.out.println(year + "년은 " + (isLeapYear ? "윤" : "평") + "년입니다.");
		
		System.out.println(System.currentTimeMillis());
		
	}

}
