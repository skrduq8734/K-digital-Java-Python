package k20230406;

import java.util.Random;
import java.util.Scanner;

public class RandomTest2 {

	public static void main(String[] args) {

		Random random = new Random();
		int com = random.nextInt(2);
		
		System.out.print("가위... 바위... 보!!! : ");
		Scanner scan = new Scanner(System.in);
		String my = scan.nextLine();
		
		System.out.print("나의 선택: " + my + "\n컴퓨터의 선택: ");
		
		// 0 = 가위,  1 = 바위,  2 = 보
		switch(com) {
		case 0:
			System.out.println("가위");
			if(my.equals("가위")) {
				System.out.println("비겼습니다!!!");
			}
			else if (my.equals("보")) {
				System.out.println("졌습니다!!!");
			}
			else {
				System.out.println("이겼습니다!!!");
			}
			break;
		case 1:
			System.out.println("바위");
			if(my.equals("바위")) {
				System.out.println("비겼습니다!!!");
			}
			else if (my.equals("가위")) {
				System.out.println("졌습니다!!!");
			}
			else {
				System.out.println("이겼습니다!!!");
			}
			break;
		case 2:
			System.out.println("보");
			if(my.equals("보")) {
				System.out.println("비겼습니다!!!");
			}
			else if (my.equals("바위")) {
				System.out.println("졌습니다!!!");
			}
			else {
				System.out.println("이겼습니다!!!");
			}
			break;
		default:
			System.out.println("잘못 입력하셨습니다!!!");
			break;
		}

	}

}
