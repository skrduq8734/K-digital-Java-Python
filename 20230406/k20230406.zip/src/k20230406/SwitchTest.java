package k20230406;

import java.util.Scanner;

public class SwitchTest {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		
		System.out.print("3과목 점수를 입력하세요: ");
		int java = scan.nextInt();
		int jsp = scan.nextInt();
		int spring = scan.nextInt();
		
		int total = java + jsp + spring;
		double average = (double) total / 3;
		System.out.printf("총점: %3d점, 평균: %6.2f\n", total, average);
		int check = (int) average / 10;
		
		switch (check) {
		case 10:
			System.out.println("참잘했어요.");
		case 9:
			System.out.println("A 입니다.");
			break;
		case 8:
			System.out.println("B 입니다.");
			break;
		case 7:
			System.out.println("C 입니다.");
			break;
		case 6:
			System.out.println("D 입니다.");
			break;		
		default:
			System.out.println("F 입니다.");
			break;
		}		
	}

}
