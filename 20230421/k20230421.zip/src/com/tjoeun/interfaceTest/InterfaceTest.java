package com.tjoeun.interfaceTest;

import java.sql.Savepoint;

class Point {
	int x, y;
	void move() {}
	public Point() {}
}
class Shape {
	// 상수는 반드시 초기화 해야함
	public final double PI;	// static은 '='
	public Shape() {
		this.PI = 3.141592;	// static 없으면 생성자로 초기화 가능
		
	}
}
// interface는 class의 특별한 형태. 무조건 상수(public static final)와 추상 메소드(public abstract)
interface Draw {
	public static final double PI = 3.141592;
	// interface는 필드에 상수만 사용 가능하기 때문에 생략시 자동으로 public static final
	int LIMIT = 1000;
	
	public abstract void movemove();
	void erase();
}
interface Graphic {
	void rotate();
	void resize();
}
// 클래스는 클래스끼리 인터페이스는 인터페이스끼리 상속을 시켜야 한다

interface Graphics extends Draw, Graphic {
	// 아무런 내용을 가지지 않은 인터페이스를 표시(marker) 인터페이스라 부른다
}
// 클래스에 인터페이스를 붙여서 사용하려면 implements(구현) 예약어를 사용해서 구현시켜 사용한다

class Line extends Point implements Draw, Graphic {

	@Override
	public void rotate() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void resize() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void movemove() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void erase() {
		// TODO Auto-generated method stub
		
	}
	
}

public class InterfaceTest {
	
	public static void main(String[] args) {
		Shape shape = new Shape();
		System.out.println("Shape.PI: " + shape.PI);
		System.out.println("Draw.PI: " + Draw.PI);
		System.out.println("Draw.PI: " + Draw.LIMIT);
	}

}
