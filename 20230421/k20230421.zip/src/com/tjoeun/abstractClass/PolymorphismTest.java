package com.tjoeun.abstractClass;

import java.util.Scanner;

//다형성: 같은 메소드가 서로 다른 클래스에서 다양하게 실행되는 것
abstract class Shape {
	int x, y;
	void move() {}
	abstract void draw();
}
class Point extends Shape {
	@Override
	void draw() {
		System.out.println("점을 찍는다");
	}
}
class Line extends Shape {
	@Override
	void draw() {
		System.out.println("선을 그린다");
	}
}
class Circle extends Shape {
	@Override
	void draw() {
		System.out.println("원을 그린다");
	}
}
class Ractangle extends Shape {
	@Override
	void draw() {
		System.out.println("사각형을 그린다");
	}
}
class Triangle extends Shape {
	@Override
	void draw() {
		System.out.println("삼각형을 그린다");
	}
}
public class PolymorphismTest {
	public static void main(String[] args) {
//		Shape shape = new Point();
//		shape.draw();
//		shape = new Line();
//		shape.draw();
//		shape = new Circle();
//		shape.draw();	
//		shape = new Ractangle();
//		shape.draw();	
//		shape = new Triangle();
//		shape.draw();
		
		Shape[] shapes = {new Point(), new Line(), new Circle(), new Ractangle(), new Triangle()};
		while (true) {
			Scanner scanner = new Scanner(System.in);
			System.out.print("원하는 작업을 선택하세요(종료: 0): ");
			int menu = scanner.nextInt();
			if (menu == 0) {
				break;
			}else if (menu > shapes.length) {
				continue;
			}
			shapes[menu-1].draw();			
		}
	}

}
