package com.tjoeun.abstractClass;

abstract class Car{
	final String name = "홍길동";
	public Car() {}
	public abstract void drive();
	public abstract void stop();
	public void startCar() {
		System.out.println("시동을 켭니다.");
	}
	public void turnOff() {
		System.out.println("시동을 끕니다.");
	}
	// 템플릿 메소드: 추상 클래스에 생성. 전체적인 흐름 정의
	public void run() {
		startCar();
		drive();
		stop();
		turnOff();
	}
}
class AICar extends Car{

	@Override
	public void drive() {
		System.out.println("자동차가 스스로 자율 주행합니다.");
		System.out.println("자동차가 스스로 방향을 변경합니다.");
	}

	@Override
	public void stop() {
		System.out.println("자동차가 스스로 멈춥니다.");
	}
}
class ManualCar extends Car{

	@Override
	public void drive() {
		System.out.println("사람이 운전합니다.");
		System.out.println("사람이 핸들을 조작해서 방향을 변경합니다.");
	}

	@Override
	public void stop() {
		System.out.println("사람이 브레이크를 밟아 자동차를 멈춥니다.");
	}
	
}

public class TemplateMethodTest {
	public static void main(String[] args) {
		
		Car manualCar = new ManualCar();
		manualCar.startCar();
		manualCar.drive();
		manualCar.stop();
		manualCar.turnOff();
		System.out.println("=========================");
		
		Car aiCar = new AICar();
		aiCar.run();
		System.out.println("=========================");
		
		System.out.println(aiCar.name);
		System.out.println(aiCar.name);
		
	}

}
