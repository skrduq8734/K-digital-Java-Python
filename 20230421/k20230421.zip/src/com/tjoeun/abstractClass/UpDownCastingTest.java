package com.tjoeun.abstractClass;

class Base {
	// 접근권한 안적으면 package -> 같은 패키지 에서는 public 다른 패키지에서는 private
	String name;
	public Base() {}
	void say() {
		System.out.println(name + "님 안녕하세요");
	}
}
class Sub extends Base {
	int age;
	public Sub() {}
	@Override
	void say() {
		System.out.println(name + "(" + age +")님 환영합니다");
	}
}
public class UpDownCastingTest {
	public static void main(String[] args) {
		
		// 부모 클래스 타입으로 부모 클래스 객체를 만들어 사용가능
		Base base = new Base();
		base.name = "이춘향";
		base.say();
		System.out.println("========================");
		
		// 자식 클래스 타임으로 자식 클래스 객채를 만들어 사용가능
		Sub sub = new Sub();
		sub.name = "텍스처";
		sub.age = 20;
		sub.say();
		System.out.println("========================");
		
		// 부모 클래스가 자식 클래스 제어 가능, 자식 클래스는 부모 클래스 제어 불가
		Base b = sub; // UpCasting
		b.say();
		System.out.println(b.name);
		
		// DownCasting 은 UpCasting 된 자식클래스를 다시 자식클래스로 만드는 것 -> unboxing
//		Sub s = (Sub) base;	// 문법적 오류는 없지만 정상적인 DownCasting이 아님 
		
		// instanceof 연산자는 클래스타입 형변환이 안전한지 검사
		if (sub instanceof Base) {
			System.out.println("Sub 클래스 타입의 객체는 Base 클래스 타입으로 형변환 가능");
		}else {
			System.out.println("Sub 클래스 타입의 객체는 Base 클래스 타입으로 형변환 불가능");
		}
		if (base instanceof Sub) {
			System.out.println("Base 클래스 타입의 객체는 Sub 클래스 타입으로 형변환 가능");
		}else {
			System.out.println("Base 클래스 타입의 객체는 Sub 클래스 타입으로 형변환 불가능");
		}
		
		try {
			Sub sub2 = (Sub) base;
			sub2.say();
		} catch (Exception e) {
			System.out.println("Base 클래스 타입의 객체는 Sub 클래스 타입으로 형변환 불가능");
		}
		System.out.println("========================");
		
		// 정상적인 다운캐스팅
		Base base2 = sub;
		
		Sub sub2 = (Sub) base2;
		sub2.say();
			
	}

}
