package com.tjoeun.abstractClass;

import java.util.ArrayList;

abstract class Animal {
	public abstract void move();
	public Animal() {}
}
class Human extends Animal {
	
	public Human() {}

	@Override
	public void move() {
		System.out.println("사람은 두발");
	}
}
class Tiger extends Animal {
	
	public Tiger() {}

	@Override
	public void move() {
		System.out.println("호랑이 네발");
	}
	private void hunting() {
		System.out.println("호랑이 사냥한다");
	}
}
class Eagle extends Animal {
	
	public Eagle() {}

	@Override
	public void move() {
		System.out.println("이건 날개");
	}
	private void flying() {
		System.out.println("독수리 날아");
	}
}
public class InstanceofTest {
	public static void main(String[] args) {
		// 배열과 인덱스 이용
		Animal[] animals = {new Human(), new Tiger(), new Eagle()};
		animals[0].move();
		animals[1].move();
		animals[2].move();
		System.out.println("=========================");
		
		// UpCasting 이용
		Animal hAnimal = new Human();
		Animal tAnimal = new Tiger();
		Animal eAnimal = new Eagle();
		moveAnimal(hAnimal);
		moveAnimal(tAnimal);
		moveAnimal(eAnimal);
		System.out.println("=========================");
		
		InstanceofTest test = new InstanceofTest();	// 자신의 클래스 객체를 만든다
		test.moveAnimal2(hAnimal);
		test.moveAnimal2(tAnimal);
		test.moveAnimal2(eAnimal);
		System.out.println("=========================");
		
		ArrayList<Animal> animalList = new ArrayList<>();
		animalList.add(hAnimal);
		animalList.add(tAnimal);
		animalList.add(eAnimal);
		for (Animal animal : animalList) {
			animal.move();
		}
		System.out.println("=========================");
		
		for (int i=0;i<animalList.size();i++) {
			Animal animal = animalList.get(i);
			if (animal instanceof Human) {
				Human human = (Human) animal;
			} else if (animal instanceof Tiger) {
				Tiger tiger = (Tiger) animal;
			} else if (animal instanceof Eagle) {
				Eagle eagle = (Eagle) animal;
			}
			else {
				System.out.println("불가능");	
			}
		}
	}

	private static void moveAnimal(Animal animal) {
		animal.move();
	}
	
	private void moveAnimal2(Animal animal) {
		animal.move();
	}
}
