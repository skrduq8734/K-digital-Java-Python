package com.tjoeun.abstractClass;

// 추상 클래스는 상속을 목적으로 만드는 클래스
abstract class Product {

	public Product() {}
	public abstract void kindOf();	// 아무런 일도 하지 않고 {}가 없음0 -> 추상 메소드
}

class Camera extends Product {
	
	public Camera() {}

	@Override
	public void kindOf() {
		
	}
}

public class AbstractClassTest {
	public static void main(String[] args) {
		
		Product product = new Product() {
			
			@Override
			public void kindOf() {
				
			}
		};
		
	}

}
